package com.nexos.nexos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexosApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.nexos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.nexos.modelos.Empleado;
import com.nexos.servicios.DepartamentoService;
import com.nexos.servicios.EmpleadoService;

import java.util.Optional;

@Controller
@RequestMapping("/empleados")
public class EmpleadoController {

    @Autowired
    private EmpleadoService empleadoService;

    @Autowired
    private DepartamentoService departamentoService;

    @GetMapping
    public String listarEmpleados(Model model) {
        model.addAttribute("empleados", empleadoService.listarTodos());
        return "empleados/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoEmpleado(Model model) {
        model.addAttribute("empleado", new Empleado());
        model.addAttribute("departamentos", departamentoService.listarTodos());
        return "empleados/formulario";
    }

    @PostMapping
    public String guardarEmpleado(@ModelAttribute Empleado empleado) {
        empleadoService.guardar(empleado);
        return "redirect:/empleados";
    }

    @GetMapping("/editar/{id}")
    public String editarEmpleado(@PathVariable int id, Model model) {
        Optional<Empleado> empleado = empleadoService.buscarPorId(id);
        if (empleado.isPresent()) {
            model.addAttribute("empleado", empleado.get());
            model.addAttribute("departamentos", departamentoService.listarTodos());
            return "empleados/formulario";
        } else {
            return "redirect:/empleados";
        }
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarEmpleado(@PathVariable int id) {
        empleadoService.eliminar(id);
        return "redirect:/empleados";
    }
}

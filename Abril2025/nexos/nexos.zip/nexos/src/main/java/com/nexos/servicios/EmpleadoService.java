package com.nexos.servicios;

import java.util.Optional;

import com.nexos.modelos.Empleado;

public class EmpleadoService {

    public Object listarTodos() {
        // TODO #1 Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'listarTodos'");
    }

    public void guardar(Empleado empleado) {
        // TODO #2 Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'guardar'");
    }

    public Optional<Empleado> buscarPorId(int id) {
        // TODO #3 Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buscarPorId'");
    }

    public void eliminar(int id) {
        // TODO #4 Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }
    
}

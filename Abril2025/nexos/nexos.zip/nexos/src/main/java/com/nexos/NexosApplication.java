package com.nexos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexosApplication {

	public static void main(String[] args) {
		SpringApplication.run(NexosApplication.class, args);
	}

}

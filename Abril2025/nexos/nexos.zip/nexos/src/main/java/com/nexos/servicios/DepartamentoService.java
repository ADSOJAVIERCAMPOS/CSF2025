package com.nexos.servicios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nexos.modelos.Departamento;
import com.nexos.repositorio.DepartamentoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class DepartamentoService {
    @Autowired
    private DepartamentoRepository departamentoRepository;

    public List<Departamento> listarTodos() {
        return departamentoRepository.findAll();
    }

    public Optional<Departamento> obtenerPorId(Integer id) {
        return departamentoRepository.findById(id);
    }

    public Departamento guardar(Departamento departamento) {
        return departamentoRepository.save(departamento);
    }

    public void eliminar(Integer id) {
        departamentoRepository.deleteById(id);
    }
}
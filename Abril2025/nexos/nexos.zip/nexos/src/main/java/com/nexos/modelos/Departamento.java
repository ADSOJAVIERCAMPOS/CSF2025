package com.nexos.modelos;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "departamentos")
public class Departamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @Column(name = "departamento_codigo", nullable = false, unique = true, length = 20)
    private String codigo;
    
    @Column(name = "departamento_nombre", nullable = false, length = 100)
    private String nombre;
    
    @Column(name = "fecha_hora_crea", updatable = false)
    private LocalDateTime fechaHoraCrea;
    
    @Column(name = "fecha_hora_modifica")
    private LocalDateTime fechaHoraModifica;
    
    @OneToMany(mappedBy = "departamento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Empleado> empleados;
    
    // Getters y Setters
}

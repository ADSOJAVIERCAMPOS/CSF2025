package com.nexos.modelos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

import javax.swing.text.Document;

@Entity
@Table(name = "empleados")
public class Empleado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "documento_tipo", nullable = false)
    private Document documentoTipo;
    
    @Column(name = "documento_numero", nullable = false, unique = true, length = 20)
    private String documentoNumero;
    
    @Column(name = "nombres", nullable = false, length = 100)
    private String nombres;
    
    @Column(name = "apellidos", nullable = false, length = 100)
    private String apellidos;
    
    @ManyToOne
    @JoinColumn(name = "departamentos_id")
    private Departamento departamento;
    
    @Column(name = "ciudad", length = 100)
    private String ciudad;
    
    @Column(name = "direccion", length = 200)
    private String direccion;
    
    @Column(name = "correo_electronico", length = 100, unique = true)
    private String correoElectronico;
    
    @Column(name = "telefono", length = 20)
    private String telefono;
    
    @Column(name = "fecha_hora_crea", updatable = false)
    private LocalDateTime fechaHoraCrea;
    
    @Column(name = "fecha_hora_modifica")
    private LocalDateTime fechaHoraModifica;

}
    
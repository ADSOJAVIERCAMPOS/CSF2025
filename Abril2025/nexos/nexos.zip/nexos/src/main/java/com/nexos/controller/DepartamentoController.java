package com.nexos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.nexos.modelos.Departamento;
import com.nexos.servicios.DepartamentoService;

import java.util.Optional;

@Controller
@RequestMapping("/departamentos")
public class DepartamentoController {
    @Autowired
    private DepartamentoService departamentoService;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("departamentos", departamentoService.listarTodos());
        return "departamentos/listar";
    }

    @GetMapping("/crear")
    public String formularioCrear(Model model) {
        model.addAttribute("departamento", new Departamento());
        return "departamentos/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Departamento departamento) {
        departamentoService.guardar(departamento);
        return "redirect:/departamentos";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditar(@PathVariable Integer id, Model model) {
        Optional<Departamento> departamento = departamentoService.obtenerPorId(id);
        if (departamento.isPresent()) {
            model.addAttribute("departamento", departamento.get());
            return "departamentos/formulario";
        }
        return "redirect:/departamentos";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id) {
        departamentoService.eliminar(id);
        return "redirect:/departamentos";
    }
}
